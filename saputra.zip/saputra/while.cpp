#include <iostream>
using namespace std;
int main(){

int i, n;
cout<<" masukan bilangan bulat (n) : ";
cin>>n;
i = n;
while ( i > 0){
    cout<<i<<" TI Unggul -> Fkom Juara -> UNIKU jaya "<<endl;
    i--;
}
    return 0;
}
