(function(){var loadHandler=window['sl_{1C7C20B0-923F-42E6-81A9-A0E7CBCD79AC}'];loadHandler&&loadHandler(2, '<div id="spr0_209740"><div id="spr1_209740" class="kern slide"><img id="img1_209740" src="data/img0.png" width="720px" height="540px" alt="" style="left:0px;top:0px;"/></div><div id="spr2_209740" class="kern slide"><div id="spr3_209740" style="left:36px;top:37.533px;"><div style="width:0px;"><span id="txt0_209740" data-width="86.328125" style="left:280.812px;top:13.464px;">No. 2</span></div></div><div id="spr4_209740" style="left:44px;top:159px;"><img id="img0_209740" src="data/img2.png" width="585" height="314" alt="Gunakan  : f’(x) =   lim 𝑡→𝑥   𝑓 𝑡 −𝑓(𝑥) 𝑡−𝑥   untuk mencari f’(x), dari fungsi berikut :\
f(x) = x2 – 3x          \
f(x) = x3 + 5x\
f(x) =  𝑥 𝑥−5 \
f(x) =  𝑥+3 𝑥 \
\
\
\
\
\
\
"/></div></div></div>');})();