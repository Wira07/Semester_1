(function(){var loadHandler=window['sl_{1C7C20B0-923F-42E6-81A9-A0E7CBCD79AC}'];loadHandler&&loadHandler(1, '<div id="spr0_208dae"><div id="spr1_208dae" class="kern slide"><img id="img1_208dae" src="data/img0.png" width="720px" height="540px" alt="" style="left:0px;top:0px;"/></div><div id="spr2_208dae" class="kern slide"><div id="spr3_208dae" style="left:19.805px;top:48.873px;"><div style="width:0px;"><span id="txt0_208dae" data-width="94.960938" style="left:295.53px;top:7.723px;">No. 1</span></div></div><div id="spr4_208dae" style="left:45px;top:153px;"><img id="img0_208dae" src="data/img1.png" width="601" height="298" alt="Gunakan definisi f’(c) =   lim ℎ→0   𝑓 𝑐+ℎ −𝑓(𝑐) ℎ  Untuk mencari turunan yang ditunjuk berikut :\
f’(1), jika f(x) = x2 \
f’(2), jika f(x) = (2x)2\
f’(3), jika f(t) = t2 – 1 \
f’(4), jika f(s) =  1 𝑠−1  \
\
\
\
\
\
"/></div></div></div>');})();