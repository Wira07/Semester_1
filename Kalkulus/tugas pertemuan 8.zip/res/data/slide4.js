(function(){var loadHandler=window['sl_{1C7C20B0-923F-42E6-81A9-A0E7CBCD79AC}'];loadHandler&&loadHandler(3, '<div id="spr0_20a13e"><div id="spr1_20a13e" class="kern slide"><img id="img1_20a13e" src="data/img0.png" width="720px" height="540px" alt="" style="left:0px;top:0px;"/></div><div id="spr2_20a13e" class="kern slide"><div id="spr3_20a13e" style="left:31.145px;top:31.863px;"><div style="width:0px;"><span id="txt0_20a13e" data-width="77.285156" style="left:287.333px;top:7.794px;">No.3</span></div></div><div id="spr4_20a13e" style="left:44px;top:127px;"><img id="img0_20a13e" src="data/img3.png" width="400" height="349" alt="Carilah turunan fungsi berikut:\
F(x) = 100/x5  \
F(x) = 𝜋x3 \
F(x) = 3x/4x5 \
F(x) = 3x4 – 2x3 – 5x2 + πx + π2 \
F(x) = (x2 + 1)2 \
F(x) = 3/x3 – 1/x4 \
F(x) =  1 3 𝑥 2 +1 \
F(x) =  2𝑥−1 𝑥 + 2 \
\
\
\
\
"/></div></div></div>');})();